#CHAN XIN ZHE/GOH JIN YIT
#TP066036/TP067376

#Delivery Staff Functionalities
def ViewNselectOrders():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~VIEW AND SELECT ORDERS FOR DELIVERY PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    alilrEC = []
    with open("DeliveryStaff.txt","r") as fh:
        for rec in fh:
            alilrEC.append(rec.strip().split(":"))
    deliStaffID = input("Please enter your staff ID again: ")
    ind = -1
    for cnt in range(len(alilrEC)):
        if (deliStaffID == alilrEC[cnt][0]):
            ind = cnt
    if (ind != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ORDERS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        allrec = []
        with open("Deliverystaff"+deliStaffID+".txt","r") as faih:
            for raic in faih:
                allrec.append(raic.strip().split(";"))
        print(raic.strip())
        selc_cusToDele = input("Please enter a customer's ID to deliver: ")
        iaind = -1
        for caint in range(len(allrec)):
            if (selc_cusToDele == allrec[caint][0]):
                iaind = caint
        for i in range(2):
            if (iaind != -1):
                allrec[iaind][3] = "Delivering order"
                
                with open("Deliverystaff"+deliStaffID+".txt","w") as fHHHh:
                    for reclist in allrec:
                        rec = ";".join(reclist) + "\n"
                        fHHHh.write(rec)
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SELECTED SUCCESSFUL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                DisplayDeliveryStaffMenu()
                break
            else:
                print("Invalid customer ID.")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                ViewNselectOrders()
                break
    else:
        print("Invalid Staff ID")
        print("Going back to Main menu")
        DisplayDeliveryStaffMenu()

def TakeFeedbackNUpdateStatus():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~TAKE FEEDBACK AND UPDATE DELIVERY STATUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    alllrEDC = []
    with open("DeliveryStaff.txt","r") as fhheheh:
        for recee in fhheheh:
            alllrEDC.append(recee.strip().split(":"))
    deliStaff_ID = input("Please enter your staff ID again: ")
    indDDDDeded = -1
    for cntntnnt in range(len(alllrEDC)):
        if (deliStaff_ID == alllrEDC[cntntnnt][0]):
            indDDDDeded = cntntnnt
    if (indDDDDeded != -1):
        allrec = []
        with open("Deliverystaff"+deliStaff_ID+".txt","r") as fhhh:
            for recc in fhhh:
                allrec.append(recc.strip().split(";"))
            print(recc.strip())
        selec_cus = input("Please select a Customer ID to insert feedback: ")
        indd = -1
        for cant in range(len(allrec)):
            if (selec_cus == allrec[cant][0]):
                indd = cant
        if (indd != -1):
            allrec[indd][3] = "Order completed delivered"
            cus_feedback = input("Please enter customer's feedback: ")
            allrec[indd][4] = cus_feedback
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL UPDATED STATUS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("Going back to main menu.")
            DisplayDeliveryStaffMenu()
        else:
            print("Record not found")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            TakeFeedbackNUpdateStatus()

        with open("Deliverystaff"+deliStaff_ID+".txt","w") as fh:
            for recluwt in allrec:
                rec = ";".join(recluwt) + "\n"
                fh.write(rec)
    else:
        print("Record not found")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayDeliveryStaffMenu()
                
def DisplayDeliveryStaffMenu():
    print("1 - View and Select Orders for Delivery")
    print("2 - Take Feedback and Update Delivery Status")
    print("3 - Exit")
    for i in range(1):
        num_selectD = str(input("Select the functionalities by number: "))
        if num_selectD == "1":
            ViewNselectOrders()
            break
        elif num_selectD == "2":
            TakeFeedbackNUpdateStatus()
            break
        elif num_selectD == "3":
            print("Exit Successful. Have a nice day!")
            break
        else:
            print("Invalid number. Please re-select a number")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayDeliveryStaffMenu()
            break

def DeliveryStaffLogin():
    allRec = []
    for z in range(3):
        with open("DeliveryStaff.txt","r") as fh:
            for rec in fh:
                allRec.append(rec.strip().split(":"))
        dsID = input("Please enter your StaffID: ")
        dsPW = input("Please enter your Password: ")
        ind = -1
        c = 2
        for cnt in range(len(allRec)):
            if (dsID == allRec[cnt][0]) and (dsPW == allRec[cnt][1]):
                ind = cnt
        if (ind != -1):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ WELCOME",allRec[ind][2],"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayDeliveryStaffMenu()
            break
        else:
            print("Record not found")
            print("Incorrect record. Try again and chances left",c-z)
            continue
    if (c-z<1):
        print("Invalid answer! Exiting...")
        print("Have a nice day!")

#Admin functionalities
def SelectWhichCategoryToModify():
    allRec = []
    with open("Category.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    catStoM = input("Please enter which category of items to modify(exp: A1): ").upper()
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROCEED TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    cHECKhvOnt = -1
    for cnt in range(len(allRec)):
        if (catStoM == allRec[cnt][0]):
            cHECKhvOnt = cnt
    if (cHECKhvOnt != -1):
        lETc = open("ItemCategory"+catStoM+".txt","r")
        print(lETc.read())
        lETc.close()
        aLLrec = []
        with open("ItemCategory"+catStoM+".txt","r") as fh:
            for rec in fh:
                aLLrec.append(rec.strip().split(":"))
        salphab = input("Please enter the alphabet to modify(exp:'a)'): ").lower()
        ind = -1
        for cnt in range(len(aLLrec)):
            if (salphab == aLLrec[cnt][0]):
                ind = cnt
        if (ind != -1):
            newProductNumbering = input(aLLrec[ind][0] + ", Please enter new product numbering(exp: 'a)'): ")
            newProductDetails = input(aLLrec[ind][1] + ", Please enter new product details(exp: 'XXX'): ")
            newBurningTime = input(aLLrec[ind][2] + ", Please enter new product burning time(exp: XX hr/'-'for NULL): ")
            newPrice = input(aLLrec[ind][3] + ", Please enter new product price(exp: XX.XX): ")
            newQuantity = input(aLLrec[ind][4] + ", Please enter new quantity given according to the price(exp: 'per piece'/'10 tin'): ")
            newStockBalance = input(aLLrec[ind][5] + ", Please enter new stock balance: ")
            aLLrec[ind][0] = newProductNumbering
            aLLrec[ind][1] = newProductDetails
            aLLrec[ind][2] = newBurningTime
            aLLrec[ind][3] = newPrice
            aLLrec[ind][4] = newQuantity
            aLLrec[ind][5] = newStockBalance
            with open("ItemCategory"+catStoM+".txt","w") as fh:
                for recList in aLLrec:
                    rec = ":".join(recList) + "\n"
                    fh.write(rec)
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODIFY COMPLETED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Record Not found")
            selcForAD = input("Do you wish to re-select(y/n): ").lower()
            if (selcForAD == "y"):
                SelectWhichCategoryToModify()
            elif (selcForAD == "n"):
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                DisplayAdminMenu()
            else:
                print("Invalid selection! Exiting...")
                print("Have a nice day!")
    else:
        print("Record Not found")
        selcForADD = input("Do you wish to re-select(y/n): ").lower()
        if (selcForADD == "y"):
            SelectWhichCategoryToModify()
        elif (selcForADD == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")


def AddCategory():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADD CATEGORY PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    letSee = open("Category.txt","r")
    print(letSee.read())
    letSee.close()
    with open("Category.txt","a") as fh:
        newCategory = ""
        addCategoryNumbering = input("Please enter new category numbering(exp: 'A4/B2'): ")
        addCategoryArea = input("Please enter new category area(exp: XXX): ")
        addCategorySection = input("Please enter new category section(exp: 1/2/3 - XXX): ")
        newCategory = addCategoryNumbering[0] + addCategoryArea[0] + addCategorySection[0]
        rec = addCategoryNumbering +":"+ addCategoryArea +" :"+ addCategorySection
        fh.write((rec)+"\n")
        if (newCategory != ""):
            nCateF = open("ItemCategory"+addCategoryNumbering+".txt","w")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADD CATEGORY SUCCESSFUL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()

def AddItemWise():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADD ITEM PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    allRec = []
    with open("Category.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    selcCateToAdd = input("Please enter a category to add items(exp: A1): ").upper()
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROCEED TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    checkHvOrNot = -1
    for cnt in range(len(allRec)):
        if(selcCateToAdd == allRec[cnt][0]):
            checkHvOrNot = cnt
    if (checkHvOrNot != -1):
        giVc = open("ItemCategory"+selcCateToAdd+".txt","r")
        print("Product Details :Burning Time :Price(RM) :Quantity :Stock Quantity\n")
        print(giVc.read())
        giVc.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE ENTER YOUR NEW ITEM~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        with open("ItemCategory"+selcCateToAdd+".txt","a") as fh:
            addNewItemAlphabet = input("Please enter the item's new numbering(Exp: 'b)/c)'): ")
            addNewItemDetails = input("Please enter a new item details(exp: 'XXX'): ")
            addNewItemBurningTime = input("Please enter the item's burning time(exp: XX hr/'-'for NULL): ")
            addNewItemPrice = input("Please enter the item's price(exp: XX.XX): ")
            addNewItemQuantity = input("Please enter the item's quantity according to the price given(exp: 'per piece'/'10 tin'): ")
            addNewStockQuantity = input("Please enter the item's stock quantity: ")
            reco = addNewItemAlphabet +":"+ addNewItemDetails +" :"+ addNewItemBurningTime +" :"+ addNewItemPrice +" :"+ addNewItemQuantity +" :"+ addNewStockQuantity
            fh.write((reco)+"\n")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL ADDED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK ADMIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
    else:
        print("Category not found!")
        selectionForADmin = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForADmin == "y"):
            AddItemWise()
        elif (selectionForADmin == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def DisplayItemWise():
    print("Product: Candles\nCategory:")
    allRec = []
    with open("Category.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    selcc_cate = str(input("Please select the category(exp:A1/A2): ")).upper()
    checkGtOnt= -1
    for cnt in range(len(allRec)):
        if(selcc_cate == allRec[cnt][0]):
            checkGtOnt = cnt
    if (checkGtOnt != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Category",selcc_cate,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Product Details :Burning Time :Price(RM) :Quantity :Stock Quantity\n")
        openForCusC = open("ItemCategory"+selcc_cate+".txt","r")
        print(openForCusC.read())
        openForCusC.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        SelectUrOpTION()
    else:
        print("Category not found.")
        selectionForCustom = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForCustom == "y"):
            SelectUrOpTION()
        elif (selectionForCustom == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")    

def SelectUrOpTION():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DISPLAY ALL RECORDS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("a - Item Category")
    print("b - Item Category-wise")
    print("c - Customer Orders")
    print("d - Customer Payment")
    print("e - Back to Main Menu")
    displaySelec = input("Please enter your selection: ").lower()
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROGRESS TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if (displaySelec == "a"):
        print("Category: ")
        oCateFile = open("Category.txt","r")
        print(oCateFile.read())
        oCateFile.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        SelectUrOpTION()
    elif (displaySelec == "b"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CHOOSE AN ITEM CATEGORY~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayItemWise()
    elif (displaySelec == "c"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DISPLAYING CUSTOMER ORDERS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Customer ID;\t\t\t\tCustomer's Order(s);\t\t\t\tAssign Order Status;\t\t\t\tOrder's Date and Time;\t\t\t\tPeyment Status;\t\t\t\tOrder's Total Price")
        oPlaceOrderFile = open("PlaceOrder.txt","r")
        print(oPlaceOrderFile.read())
        oPlaceOrderFile.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        SelectUrOpTION()
    elif (displaySelec == "d"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DISPLAYING CUSTOMER PAYMENT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Customer ID:\tOrder's Total Price:\tCustomer's Address:\tPayment Method:\tCard Details(optional)")
        oMakePaymentFile = open("MakePayment.txt","r")
        print(oMakePaymentFile.read())
        oMakePaymentFile.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        SelectUrOpTION()
    elif (displaySelec == "e"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayAdminMenu()
    else:
        print("Invalid selection.")
        selectionForDisplayRecords = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForDisplayRecords == "y"):
            SelectUrOpTION()
        elif (selectionForDisplayRecords == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")        

def ModifyDeliveryStaff():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODIFY DELIVERY STAFF PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    allReccc = []
    with open ("DeliveryStaff.txt","r") as fh:
        for rec in fh:
            allReccc.append(rec.strip().split(":"))
            print(rec.strip())
    modDSID = input("Please enter the Delivery staff ID to modify: ")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROCEED TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    checkAdaTak = -1
    for cnt in range(len(allReccc)):
        if(modDSID == allReccc[cnt][0]):
            checkAdaTak = cnt
    if (checkAdaTak != -1):
        newPasswordDeliveryStaff = input(allReccc[checkAdaTak][1] + " Please enter new password: ")
        newNameDeliveryStaff = input(allReccc[checkAdaTak][2] + " Please enter new name: ")
        allReccc[checkAdaTak][1] = newPasswordDeliveryStaff
        allReccc[checkAdaTak][2] = newNameDeliveryStaff
        with open("DeliveryStaff.txt","w") as fh:
            for recList in allReccc:
                rec = ":".join(recList) + "\n"
                fh.write(rec)
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODIFY COMPLETED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayAdminMenu()
    else:
        print("Record Not Found")
        selcForADmodify = input("Do you wish to re-select(y/n): ").lower()
        if (selcForADmodify == "y"):
            ModifyDeliveryStaff()
        elif (selcForADmodify == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def DeleteDeliveryStaff():
    allRec = []
    with open("DeliveryStaff.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    sStaffToDlt = input("Please enter staff ID to delete: ")
    ind = -1
    for cnt in range(len(allRec)):
        if (sStaffToDlt == allRec[cnt][0]):
            ind = cnt
    if (ind != -1):
        print("Delivery Staff ID: " + allRec[ind][0])
        print("Delivery Staff Password: " + allRec[ind][1])
        print("Delivery Staff Name: " + allRec[ind][2])
        ques = input("Are you sure to delete this record(y/n): ").lower()
        if (ques == "y"):
            with open("DeliveryStaff.txt","w") as fh:
                for cnt in range(len(allRec)):
                    if (cnt != ind):
                        rec = ":".join(allRec[cnt]) + "\n"
                        fh.write(rec)
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL DELETED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        AddOmOsOdStaff()
        elif (ques == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
        else:
            print("Invalid selection! ")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
    else:
        print("Record not found")
        selcForADmodify = input("Do you wish to re-select(y/n): ").lower()
        if (selcForADmodify == "y"):
            ModifyDeliveryStaff()
        elif (selcForADmodify == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")        

def SearchDeliveryStaff():
    allRec = []
    with open("DeliveryStaff.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
    staffSearch = input("Please enter delivery staff ID to search: ")
    ind = -1
    for cnt in range(len(allRec)):
        if (staffSearch == allRec[cnt][0]):
            ind = cnt
    if (ind != -1):
        print("Delivery Staff ID: " + allRec[ind][0])
        print("Delivery Staff Password: " + allRec[ind][1])
        print("Delivery Staff Name: " + allRec[ind][2])
        print("Customer's ID(in charge); Item that customer(s) ordered; Customer's address; Delivery status; Customer's feedback")
        allRECCC = []
        with open("Deliverystaff"+staffSearch+".txt","r") as faihh:
            for raic in faihh:
                allRECCC.append(raic.strip().split(";"))
                print(raic.strip())
        print("~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^DELIVERY STAFF ACHIEVEMENT^^^^^^^^^^~~~~~~~~~~~~~~~~~~~~~~")
        quES = input("Do you wish to continue for searching(y/n): ").lower()
        if (quES == "y"):
            SearchDeliveryStaff()
        elif (quES == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
        else:
            print("Invalid selection! ")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()            
    else:
        print("Record not found")
        selcForADsearch = input("Do you wish to re-select(y/n): ").lower()
        if (selcForADsearch == "y"):
            SearchDeliveryStaff()
        elif (selcForADsearch == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AddOmOsOdStaff()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def AddOmOsOdStaff():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SELECT YOUR DECISION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("1 - Add Delivery Staff")
    print("2 - Modify Delivery Staff")
    print("3 - Search Delivery Staff")
    print("4 - Delete Delivery Staff")
    print("5 - Back To Previous Page")
    decDS = str(input("Please enter your decision: "))
    if (decDS == "1"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADD DELIVERY STAFF PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        allRec = []
        with open("DeliveryStaff.txt","r") as fh:
            for rec in fh:
                allRec.append(rec.strip().split(":"))
                print(rec.strip())
        with open("DeliveryStaff.txt","a") as fh:
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ENTER NEW DELIVERY STAFF DETAILS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            addNewDelStafID = input("Please enter new delivery staff ID: ")
            addNewDelStafPW = input("Please enter new Password: ")
            addNewDelStafName = input("Please enter new delivery staff name: ")
            recor = addNewDelStafID +":"+ addNewDelStafPW +":"+ addNewDelStafName
            fh.write((recor)+"\n")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL ADDED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            OrderDeliveryManagement()
    elif (decDS == "2"):
        ModifyDeliveryStaff()
    elif (decDS == "3"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING TO SEARCH STAFF~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        SearchDeliveryStaff()
    elif (decDS == "4"):
        DeleteDeliveryStaff()
    elif (decDS == "5"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        OrderDeliveryManagement()
    else:
        print("Invalid selection.")
        selectionForStaffManagDS = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForStaffManagDS == "y"):
            AddOmOsOdStaff()
        elif (selectionForStaffManagDS == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            OrderDeliveryManagement()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def AssignOrder():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ASSIGN ORDER PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("Delivery Staff's ID: Delivery Staff's Password: Delivery Staff's Username")
    aLlLLLrec = []
    with open("DeliveryStaff.txt","r") as fHHHhhhhhh:
        for rec in fHHHhhhhhh:
            aLlLLLrec.append(rec.strip().split(":"))
            print(rec.strip())
    selectStaff = input("Please enter the delivery staff's ID to assign order(s) to him/her: ")
    indDddd = -1
    for cnt in range(len(aLlLLLrec)):
        if (selectStaff == aLlLLLrec[cnt][0]):
            indDddd = cnt
    if (indDddd != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CUSTOMERS ORDERS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Customer's ID; Customer's order(s); Assign Order Status; Order's Date and Time; Payment Status; Total price(RM)")
        aLlrEC = []
        with open("PlaceOrder.txt","r") as fh:
            for rec in fh:
                aLlrEC.append(rec.strip().split(";"))
                print(rec.strip())
        aLLLLLLRECCCCCCC = []
        with open("MakePayment.txt","r") as fHHhHHHH:
            for reccc in fHHhHHHH:
                aLLLLLLRECCCCCCC.append(reccc.strip().split(":"))
        selcCusOrder = input("Please select a customer's ID to deliver: ")
        tprice = input("Please enter customer's order total price to assign(Exp: 120.0): ")
        inD = -1
        inDDD = -1
        for cNt in range(len(aLlrEC)):
            if (selcCusOrder == aLlrEC[cNt][0] and tprice == aLlrEC[cNt][-1]):
                inD = cNt
        for cNNt in range(len(aLLLLLLRECCCCCCC)):
            if (selcCusOrder == aLLLLLLRECCCCCCC[cNNt][0]):
                inDDD = cNNt
        if (inD != -1 and inDDD != -1):
            doubConfirm = input("Are you sure to deliver this order(YES/NO): ").upper()
            if (doubConfirm == "YES"):
                allllllRRRRRec = []
                with open("Deliverystaff"+selectStaff+".txt","a") as fHhhhhhhhh:
                    record = selcCusOrder +";"+ aLlrEC[inD][1] +";"+ aLLLLLLRECCCCCCC[inDDD][2] +";"+ "Waiting for deliver" +";"+ "No feedback yet"
                    fHhhhhhhhh.write((record)+"\n")
                ailreco = []
                with open("PlaceOrder.txt","r") as fiii:
                    for rec in fiii:
                        ailreco.append(rec.strip().split(";"))
                iaind = -1
                for caint in range(len(ailreco)):
                    if (selcCusOrder == ailreco[caint][0]):
                        iaind = caint
                if (iaind != -1):
                    ailreco[iaind][2] = "Order Assigned"
                    
                with open("PlaceOrder.txt","w") as faih:
                    for reclist in ailreco:
                        rec = ";".join(reclist) + "\n"
                        faih.write(rec)
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ASSIGN SUCCESSFUL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                DisplayAdminMenu()
            elif (doubConfirm == "NO"):
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ASSIGN ERROR~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                OrderDeliveryManagement()
            else:
                print("Invalid answer.")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                OrderDeliveryManagement()
        else:
            print("Invalid customer's ID ")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            AssignOrder()
    else:
        print("Delivery staff ID not found. Please try again")
        AssignOrder()
                
def OrderDeliveryManagement():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ORDER DELIVERY STAFF RECORDS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("a - Add/Modify/Search/Delete Delivery Staff")
    print("b - Assign Order to Delivery Staff")
    print("c - Back to Main Menu")
    reqForDM = input("Please enter your requirement: ").lower()
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROGRESS TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if (reqForDM == "a"):
        AddOmOsOdStaff()
    elif (reqForDM == "b"):
        AssignOrder()
    elif (reqForDM == "c"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayAdminMenu()
    else:
        print("Invalid selection.")
        selectionForStaffManag = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForStaffManag == "y"):
            OrderDeliveryManagement()
        elif (selectionForStaffManag == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")        

def SearchCusOrder():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SEARCH CUSTOMER'S ORDER RECORDS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    aLlReC = []
    with open("PlaceOrder.txt","r") as fHHHHHHHHHHHHHHH:
        for rec in fHHHHHHHHHHHHHHH:
            aLlReC.append(rec.strip().split(";"))
    orderSearch = input("Please enter customer's ID to search: ")
    orderpay = input("Please enter customer's order payment amount to search(Exp: 120.0): ")
    inDDD = -1
    for cnt in range(len(aLlReC)):
        if (orderSearch == aLlReC[cnt][0] and orderpay == aLlReC[cnt][-1]):
            inDDD = cnt
    if (inDDD != -1):
        print("Customer ID: "+ aLlReC[inDDD][0])
        print("Customer's order(s): "+ aLlReC[inDDD][1])
        print("Order's assign status: "+ aLlReC[inDDD][2])
        print("Order's date and time: "+ aLlReC[inDDD][3])
        print("Order's payment status: "+ aLlReC[inDDD][4])
        print("Total price(RM): "+ aLlReC[inDDD][-1])
        qUESTI = input("Do you wish to continue for searching(y/n): ").lower()
        if (qUESTI == "y"):
            SearchCusOrder()
        elif (qUESTI == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
        else:
            print("Invalid selection! ")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
    else:
        print("Record not found")
        dOUBBBBconfirm = input("Do you wish to re-select(y/n): ").lower()
        if (dOUBBBBconfirm == "y"):
            SearchCusOrder()
        elif (dOUBBBBconfirm == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def SearchCusPayment():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SEARCH CUSTOMER'S PAYMENT RECORDS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    alLrEcC = []
    with open("MakePayment.txt","r") as fHhHhHhHhHHHHhhhh:
        for recc in fHhHhHhHhHHHHhhhh:
            alLrEcC.append(recc.strip().split(":"))
    paymentSearch = input("Please enter customer's ID to search: ")
    totalPay = input("Please enter customer's payment amount to search(Exp: 120.0): ")
    iNDdd = -1
    for cnt in range(len(alLrEcC)):
        if (paymentSearch == alLrEcC[cnt][0] and totalPay == alLrEcC[cnt][1]):
            iNDdd = cnt
    if (iNDdd != -1):
        print("Customer ID: "+ alLrEcC[iNDdd][0])
        print("Total price(RM): "+ alLrEcC[iNDdd][1])
        print("Customer's address: "+ alLrEcC[iNDdd][2])
        print("Customer's payment method: "+ alLrEcC[iNDdd][3])
        if (alLrEcC[iNDdd][4] != ""):
            print("Customer's card details(Card's owner name :Card number :Card expire date :Card pin number): "+ str(alLrEcC[iNDdd][4:]))
        quesTiOn = input("Do you wish to continue for searching(y/n): ").lower()
        if (quesTiOn == "y"):
            SearchCusPayment()
        elif (quesTiOn == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
        else:
            print("Invalid selection! ")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
    else:
        print("Record not found")
        dOUbLEEEconfirm = input("Do you wish to re-select(y/n): ").lower()
        if (dOUbLEEEconfirm == "y"):
            SearchCusPayment()
        elif (dOUbLEEEconfirm == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            SearchSpecRecord()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")
     
def SearchSpecRecord():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SEARCH SPECIFIC RECORDS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("a - Customer Order")
    print("b - Customer Payment")
    print("c - Back to Main Menu")
    specRecReq = input("Please enter your requirement: ").lower()
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROGRESS TO NEXT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if (specRecReq == "a"):
        SearchCusOrder()
    elif (specRecReq == "b"):
        SearchCusPayment()
    elif (specRecReq == "c"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO ADMIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayAdminMenu()
    else:
        print("Invalid selection.")
        selectionForStaffManag = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForStaffManag == "y"):
            OrderDeliveryManagement()
        elif (selectionForStaffManag == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

def DisplayAdminMenu():
    print("1 - Add Category")
    print("2 - Add Item Category(wise)")
    print("3 - Modify Item")
    print("4 - Display All Records")
    print("5 - Search Specific Records")
    print("6 - Order Delivery Management")
    print("7 - Exit")
    for i in range(3):
        num_select = str(input("Select the functionalities by number: "))
        t=2
        if (num_select == "1"):
            AddCategory()
            break
        elif (num_select == "2"):
            AddItemWise()
            break
        elif (num_select == "3"):
            SelectWhichCategoryToModify()
            break
        elif (num_select == "4"):
            SelectUrOpTION()
            break
        elif (num_select == "5"):
            SearchSpecRecord()
            break
        elif (num_select == "6"):
            OrderDeliveryManagement()
            break
        elif (num_select == "7"):
            print("Exit Successful. Have a nice day!")
            break
        else:
            print("Invalid number. ")
            print("Please re-select a number, and your chances left",t-i)
            continue
    if(t-i<1):
        print("Exiting...")
        print("Have a nice day")

def AdminLogin():
    allRec = []
    for i in range(3):
        with open("Admin.txt","r") as fh:
            for rec in fh:
                allRec.append(rec.strip().split(":"))
        adID = input("Please enter your AdminID: ")
        adPW = input("Please enter your Password: ")
        ind = -1
        t = 2
        for cnt in range(len(allRec)):
            if (adID == allRec[cnt][0]) and (adPW == allRec[cnt][1]):
                ind = cnt
        if (ind != -1):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ WELCOME",allRec[ind][2],"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayAdminMenu()
            break
        else:
            print("Record not found")
            print("Incorrect Password try again and chances left",t-i)
            continue
    if (t-i<1):
        print("Exiting...")
        print("Have a nice day")
    
#Customer Functionalities
def ReviewItem():
    print("Product: Candles\nCategory:")
    allRec = []
    with open("Category.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    selc_cate = str(input("Please select the category(exp:A1/A2): ")).upper()
    checkGtOnt= -1
    for cnt in range(len(allRec)):
        if(selc_cate == allRec[cnt][0]):
            checkGtOnt = cnt
    if (checkGtOnt != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Category",selc_cate,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Product Details :Burning Time :Price(RM) :Quantity :Stock Quantity\n")
        openForCusC = open("ItemCategory"+selc_cate+".txt","r")
        print(openForCusC.read())
        openForCusC.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayCustomerMenu()
    else:
        print("Category not found.")
        selectionForCustom = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForCustom == "y"):
            ReviewItem()
        elif (selectionForCustom == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayCustomerMenu()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")                     

def MakePayment():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MAKE PAYMENT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    allRec = []
    with open("PlaceOrder.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(";"))
    confID = input("Please re-enter your ID for confirm your order: ")
    confPrice = input("Please enter your order total price that have to pay(exp: 100.0): ")
    ind = -1
    for cnt in range(len(allRec)):
        if (confID == allRec[cnt][0] and confPrice == allRec[cnt][-1]):
            ind = cnt
    if (ind != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GREAT TO SEE YOU HERE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Please confirm your order.")
        print(allRec[ind][1])
        print("Payment Status: " + allRec[ind][4])
        confOrder = input("The record above are your order and you wish to continue(y/n): ").lower()
        if (confOrder == "y"):
            print("Total price= RM "+allRec[ind][-1]) 
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^TOTAL PRICE^^^^^~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            cusAddress = ""
            cusAddress = str(input("Please enter your full address to be ship: "))
            if (cusAddress != ""):
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROGRESS TO PAYMENT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                payMethod = input("Please select your payment method(CARD - credit card online payment/CASH - cash payment when order arrived): ").upper()
                if (payMethod == "CARD"):
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ONLINE PAYMENT~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    print("Amount need to be pay: RM "+allRec[ind][-1])
                    cardName = str(input("Please enter the card owner's name: "))
                    cardNum = str(input("Please enter your card number(exp: '0123456789101112'): "))
                    cardExp = str(input("Please enter your card expire date(exp: '05/28'): "))
                    cardSer = str(input("Please enter your card series number(exp: '888'): "))
                    doubConf = input("DO YOU CONFIRMED TO MAKE PAYMENT(Y/N): ").upper()
                    if (doubConf == "Y"):
                        with open("MakePayment.txt","a") as fhHh:
                            cardpaymentdetails = confID +":"+ allRec[ind][-1] +":"+ cusAddress +":"+ payMethod +":"+ cardName +":"+ cardNum +":"+ cardExp +":"+ cardSer 
                            fhHh.write((cardpaymentdetails)+"\n")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL PAYMENT~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~YOUR PARCEL WILL BE ARRIVED WITHIN 10 WORKING DAYS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~THANK YOU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE COME AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        allRec[ind][4] = "Order Paid"

                        with open("PlaceOrder.txt","w") as faihhh:
                            for reclist in allRec:
                                recc = ";".join(reclist) + "\n"
                                faihhh.write(recc)
                        DisplayCustomerMenu()
                    elif (doubConf == "N"):
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PAYMENT CANCELLED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        DisplayCustomerMenu()
                    else:
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PAYMENT CANCELLED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        DisplayCustomerMenu()
                elif (payMethod == "CASH"):
                    with open("MakePayment.txt","a") as fhHH:
                        cashpaymentdetails = confID +":"+ allRec[ind][-1] +":"+ cusAddress +":"+ payMethod +":"+ ""
                        fhHH.write((cashpaymentdetails)+"\n")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CASH PAYMENT~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    print("Your parcel will be arrived within 10 working days.")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~THANK YOU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~COME AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    allRec[ind][4] = "Order Paid"

                    with open("PlaceOrder.txt","w") as faihh:
                        for reclist in allRec:
                            reccc = ";".join(reclist) + "\n"
                            faihh.write(reccc)
                    DisplayCustomerMenu()
                else:
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~INVALID METHOD~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    MakePayment()
            else:
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~INVALID ADDRESS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                MakePayment()
        elif (confOrder == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ORDER CANCELLED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE REPLACE YOUR ORDER~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayCustomerMenu()
        else:
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~INVALID ANSWER~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayCustomerMenu()
    else:
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~INVALID ID~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayCustomerMenu()
                    

def PlaceOrder():
    allREC = []
    shoppingDict = {}
    with open("customer.txt","r") as fh:
        for rec in fh:
            allREC.append(rec.strip().split(":"))
    cUSTMID = input("Please re-enter your ID for placing order purpose: ")
    ind = -1
    for cnt in range(len(allREC)):
        if (cUSTMID == allREC[cnt][0]):
            welcMsg = f"Welcome to APU ONLINE SHOPPING MALL(AOSM), {allREC[cnt][2]}"
            lenWCmsg = len(welcMsg)
            print("*"*lenWCmsg)
            print(welcMsg)
            print("*"*lenWCmsg)
            ind = cnt
    if (ind != -1):
        aLLrec = []
        with open("Category.txt","r") as fH:
            for rec in fH:
                aLLrec.append(rec.strip().split(":"))
                print(rec.strip())
        categ_selc = str(input("Please enter the item category you wish to purchase(exp: A1): ")).upper()
        inD = -1
        for cnt in range(len(aLLrec)):
            if (categ_selc == aLLrec[cnt][0]):
                inD = cnt
        if (inD != -1):
            allRec = []
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Category",categ_selc,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("Product Details :Burning Time :Price(RM) :Quantity :Stock Quantity(unit's')\n")
            with open("ItemCategory"+categ_selc+".txt","r") as fhh:
                for rec in fhh:
                    allRec.append(rec.strip().split(":"))
                    print(rec.strip())
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^PRODUCT DETAILS^^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            proceedShopping = input("Do you wish to proceed (Y/N): ").upper()
            while (proceedShopping == "Y"):
                item_selc = input("Please enter the product you wish to purchase(exp:'a)'/'b)'): ").lower()
                indv = -1
                for cntTT in range(len(allRec)):
                    if (item_selc == allRec[cntTT][0]):
                        indv = cntTT
                if (indv != -1):
                    amount_needed = int(input(allRec[indv][1] +" :"+ allRec[indv][2] +" :"+ allRec[indv][3] +" :"+ allRec[indv][4] +" :"+ allRec[indv][5] +" >"+ " Amount needed: "))
                    shoppingDict.update({"Category: "+categ_selc+", Item: "+item_selc:{"quantity":amount_needed,"subtotal(RM)":float(allRec[indv][3])*amount_needed}})
                    print(shoppingDict)
                    indvv = -1
                    for cnttt in range(len(allRec)):
                        if (amount_needed <= int(allRec[indv][5])):
                            indvv = cnttt
                    if (indvv != -1):
                        original_stock = allRec[indv][5]
                        remain_stock = int(original_stock) - amount_needed
                        allRec[indv][5] = str(remain_stock)
                        with open("ItemCategory"+categ_selc+".txt","w") as fHHHHHHH:
                            for reCLisT in allRec:
                                reC = ":".join(reCLisT) + "\n"
                                fHHHHHHH.write(reC)
                            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SUCCESSFUL ADD TO CART~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    else:
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FAIL ADD TO CART~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("Item stock quantity not enough!!")
                        print("Please re-enter the quantity of product needed according to our stock quantity.")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE SELECT AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        PlaceOrder()
                        break
                else:
                    print("Item not found. Please try again.")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK ORDER PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    PlaceOrder()
                    break
                proceed_Shopping = input("Do you wish to add more items(y/n): ").lower()
                if (proceed_Shopping == "y"):
                    continue
                else:
                    import datetime
                    x = datetime.datetime.now()
                    print("\n\n")
                    print("********************************Bill Summary********************************")
                    print("***********************APU ONLINE SHOPPING MALL(AOSM)***********************")
                    print("Current Date and Time: ",x)
                    print("Item\t\t\t\t\tQuantity\t\tSubtotal")
                    total = 0
                    for record in shoppingDict:
                        print(f"{record}\t\t\t{shoppingDict[record]['quantity']}\t\t\t{shoppingDict[record]['subtotal(RM)']}")
                        total = shoppingDict[record]['subtotal(RM)']+total
                        print(f"Total: {total}")
                    print("**********************************Thank You**********************************")
                    print("Please screenshot your receipt above.")
                    print("Please do remember your ID and total price have to pay to proceed make payment page")
                    print("Hope to see you back soon!")
                    with open("PlaceOrder.txt","a") as fHHHHH:
                        placeOrderRec = cUSTMID +";"+ str(shoppingDict) +";"+ "Waiting for assign" +";"+ str(x) +";"+ "Waiting for pay" +";"+ str(total)
                        fHHHHH.write((placeOrderRec)+"\n")
                    makePaymentQnA = input("Do you wish to continue make payment(y/n): ").lower()
                    if (makePaymentQnA == "y"):
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING TO MAKE PAYMENT PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        MakePayment()
                        break
                    elif (makePaymentQnA == "n"):
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        DisplayCustomerMenu()
                        break
                    else:
                        print("Invalid answer.")
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        DisplayCustomerMenu()
                        break
            else:
                print("We are sorry you don't want to purchase this time. Hope to see you back soon!")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                DisplayCustomerMenu()
        else:
            print("Item not found. Please try again")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK ORDER PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            PlaceOrder()
    else:
        print("ID not found. Please try again.")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK MAIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DisplayCustomerMenu()

def DisplayCustomerMenu():
    print("A. View Detail of Category")
    print("B. Place an Order(Select Item and add to card")
    print("C. Make payment to confirm order placement")
    print("D. Exit")
    for i in range(1):
        cusChoice = input("Please enter your choice: ").upper()
        if (cusChoice == "A"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~REVIEW ITEM PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            ReviewItem()
        elif (cusChoice == "B"):
            print("\nREMINDER!!!!!!")
            print("Dear customer, you are not allow to place order again before you successful make payment. \n(If you have placed an order but have not paid for it.)\n")
            paymConform = input("Did you pay for your last order(y/n): ").lower()
            if (paymConform == "y"):
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLACE ORDER PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                PlaceOrder()
            elif (paymConform == "n"):
                MakePayment()
            else:
                print("Invalid answer! Please re-enter your requirement.")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                DisplayCustomerMenu()
        elif (cusChoice == "C"):
            MakePayment()
        elif (cusChoice == "D"):
            print("Exit successful. Have a nice day!")
            break
        else:
            print("Invalid answer! Please re-enter your requirement.")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayCustomerMenu()

#Customer Login Page
def LoginPage():
    allRec = []
    for x in range(3):
        with open("customer.txt","r") as fh:
            for rec in fh:
                allRec.append(rec.strip().split(":"))
        idvalue = input("Please enter your ID: ")
        pwvalue = input("Please enter your Password: ")
        ind = -1
        h = 2
        for cnt in range(len(allRec)):
            if (idvalue == allRec[cnt][0]) and (pwvalue == allRec[cnt][1]):
                ind = cnt
        if (ind != -1):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ WELCOME",allRec[ind][2],"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            DisplayCustomerMenu()
            break
        else:
            print("Record not found")
            print("Incorrect record. Try again and chances left",h-x)
            continue
    if (h-x<1):
        print("Exiting...")
        print("Have a nice day!")

def AddMember():
    with open("customer.txt","a") as fh:
        cusID = input("Please enter customer ID: ")
        cusPassword = input("Please enter customer Password: ")
        cusName = input("Please enter customer name: ")
        rec = cusID +":"+ cusPassword +":"+ cusName
        fh.write((rec)+"\n")
    aMopt = input("Do you wish to continue to login page? (y/n): ").lower()
    if (aMopt == "y"):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~LOGIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        LoginPage()
    elif (aMopt == "n"):
        print("Exit successful. Have a nice day!")
    else:
        print("Invalid answer! Going back to Main Page.")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        FirstPageProgramStart()

#NEW FUNCTION
def ViewAllItems():
    print("Product: Candles\nCategory:")
    allRec = []
    with open("Category.txt","r") as fh:
        for rec in fh:
            allRec.append(rec.strip().split(":"))
            print(rec.strip())
    selc_cate = str(input("Please select the category(exp:A1/A2): ")).upper()
    checkGtOnt= -1
    for cnt in range(len(allRec)):
        if(selc_cate == allRec[cnt][0]):
            checkGtOnt = cnt
    if (checkGtOnt != -1):
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Category",selc_cate,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Product Details :Burning Time :Price(RM) :Quantity :Stock Quantity\n")
        openForCusC = open("ItemCategory"+selc_cate+".txt","r")
        print(openForCusC.read())
        openForCusC.close()
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        FirstPageProgramStart()
    else:
        print("Category not found.")
        selectionForCustom = input("Do you wish to re-select(y/n): ").lower()
        if (selectionForCustom == "y"):
            ViewAllItems()
        elif (selectionForCustom == "n"):
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GOING BACK TO PREVIOUS PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            FirstPageProgramStart()
        else:
            print("Invalid selection! Exiting...")
            print("Have a nice day!")

#First Page
def FirstPageProgramStart():
    print("WELCOME to APU Online Shopping Mall(AOSM)")
    print("Please select the progress you want to continue according to the selection below.")
    print("A - View all items as per category.")#Changes
    print("B - Register (Unregistered Customer)")#THE numbering aslo changes 
    print("C - Login (Registered Customer)")
    print("D - Admin Login Page")
    print("E - Delivery Staff Login Page")
    print("F - Exit")
    req_selected = input("Please enter your requirement: ").upper()
    if req_selected == "A":
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~VIEW ALL ITEMS AS PER CATEGORY PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")#CHanges
        ViewAllItems()#New function
    elif req_selected == "B":
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~REGISTRATION PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        AddMember()
    elif req_selected == "C":#The numbering also changed
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CUSTOMER LOGIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        LoginPage()
    elif req_selected == "D":
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADMIN LOGIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        AdminLogin()
    elif req_selected == "E":
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DELIVERY STAFF LOGIN PAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        DeliveryStaffLogin()
    elif req_selected == "F":
        print("Exit successful. Have a nice day!")
    else:
        print("Invalid answer! Please re-enter your requirement.")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PLEASE TRY AGAIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        FirstPageProgramStart()

#MAIN LOGIC
FirstPageProgramStart()
